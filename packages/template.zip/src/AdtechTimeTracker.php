<?php

namespace Adtech\AdtechTimeTracker;

class AdtechTimeTracker
{
    // Build your next great package.
}
